function addsectionhide()
{
	// body...
	document.getElementById("addsection").style.display ="none";
}

function hidequeue()
{
	// body...
	document.getElementById("songList").style.display ="none";
}